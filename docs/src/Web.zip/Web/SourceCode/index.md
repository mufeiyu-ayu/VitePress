# 手搓 element-plus 源码

## 为什么想学习 element-plus 源码

当我入职这家公司的时候发现这家公司所采用的前端工程化是 monorepo+workspace+turbo 的架构，并且当我接触公司业务时，发现封装了很多不错了业务组件和基础组件，我从同事的代码中学习到了很多，也深刻意识到自己的不足，因此我想要从基础开始逐步完善自己对于组件封装的能力，这篇 md 会记录自己学习 element-plus 的过程.<br/>

[项目仓库](https://github.com/mufeiyu-ayu/web-build)

| 学习时间  | 组件       | 是否学习 |
| --------- | ---------- | -------- |
| 2024-5-3  | button     | ✔        |
| 2024-3-24 | workspace  | ✔        |
| 2024-3-24 | axios 封装 | ✔        |
