<!--@include: ./typeof.md-->
<!--@include: ./instanceof.md-->
<!--@include: ./constructor.md-->
<!--@include: ./toString.md-->
