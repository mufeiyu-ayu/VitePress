防抖，节流=>合理控制在一段时间内函数反复执行的次数<br />防抖：只在规定时间内连续触发n次，最终只执行一次<br />节流：在规定时间内连续触发n次，按规律降低执行频率

具体访问-------------------[https://blog.csdn.net/qq_15905635/article/details/106783103](https://blog.csdn.net/qq_15905635/article/details/106783103)
