<!--@include: ./promise.md-->
<!-- @include: ./sourcePromise.md -->
<!--@include: ./promisedef.md-->
