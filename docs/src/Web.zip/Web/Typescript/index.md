---
layout: doc
---

# TypeScript

[官方文档](https://www.typescriptlang.org/zh/)

<!-- @include:./own/note.md -->
<!-- @include:./own/typePractice.md -->
